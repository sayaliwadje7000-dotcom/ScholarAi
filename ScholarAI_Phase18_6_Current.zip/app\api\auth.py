"""
ScholarAI Authentication API.

Phase 18.2: Registration.
Phase 18.4: Login and credential verification.
Phase 18.5: JWT access token issuance.
"""

import logging

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    status,
)

from sqlalchemy.orm import Session

from app.database.session import get_db

from app.schemas.auth import (
    UserRegistrationRequest,
    UserRegistrationResponse,
    UserLoginRequest,
    UserLoginResponse,
)

from app.services.auth_service import auth_service

from app.services.auth_exceptions import (
    AuthenticationError,
)

from app.security.token import create_access_token

from app.security.token_exceptions import (
    TokenCreationError,
)


logger = logging.getLogger(__name__)

router = APIRouter()


@router.post(
    "/register",
    response_model=UserRegistrationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new ScholarAI user",
    description=(
        "Creates a new ScholarAI account after validating "
        "registration details and securely hashing "
        "the submitted password."
    ),
)
def register_user(
    request: UserRegistrationRequest,
    db: Session = Depends(get_db),
) -> UserRegistrationResponse:
    """
    Register a new user account.
    """

    try:

        user = auth_service.register_user(
            db=db,
            request=request,
        )

        return UserRegistrationResponse.model_validate(
            user
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    except Exception as exc:

        logger.exception(
            "Unexpected error during registration."
        )

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Unable to register the account.",
        ) from exc


@router.post(
    "/login",
    response_model=UserLoginResponse,
    status_code=status.HTTP_200_OK,
    summary="Authenticate a ScholarAI user",
    description=(
        "Verifies user credentials and issues a signed "
        "JWT access token after successful authentication."
    ),
)
def login_user(
    request: UserLoginRequest,
    db: Session = Depends(get_db),
) -> UserLoginResponse:
    """
    Authenticate a user and issue a JWT access token.
    """

    try:

        # STEP 1: Verify login credentials.

        user = auth_service.authenticate_user(
            db=db,
            request=request,
        )

        # STEP 2: Generate JWT access token.

        access_token, expires_in = create_access_token(
            user_id=user.id,
        )

        # STEP 3: Return authenticated user and token.

        return UserLoginResponse(
            authenticated=True,
            message="Login successful.",
            user=UserRegistrationResponse.model_validate(
                user
            ),
            access_token=access_token,
            token_type="bearer",
            expires_in=expires_in,
        )

    except AuthenticationError as exc:

        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password.",
            headers={
                "WWW-Authenticate": "Bearer",
            },
        ) from exc

    except TokenCreationError as exc:

        logger.exception(
            "JWT access-token creation failed."
        )

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Unable to complete login.",
        ) from exc

    except Exception as exc:

        logger.exception(
            "Unexpected login failure."
        )

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Unable to complete login.",
        ) from exc