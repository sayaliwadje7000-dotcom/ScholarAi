"""
Security utilities for ScholarAI.
"""