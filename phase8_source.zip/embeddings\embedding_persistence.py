from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.embedding_config import EmbeddingSettings
from app.models.chunk_embedding import ChunkEmbedding
from app.models.document_chunk import DocumentChunk
from app.services.embeddings.embedding_pipeline import (
    ChunkEmbeddingOutcome,
)


PIPELINE_VERSION = "1.0.0"
DATABASE_VECTOR_DIMENSIONS = 1536


class EmbeddingPersistenceError(Exception):
    """Base exception for embedding persistence errors."""


class EmbeddingPersistenceValidationError(
    EmbeddingPersistenceError
):
    """Raised when embedding data fails persistence validation."""


@dataclass(frozen=True)
class EmbeddingPersistenceResult:
    total: int
    inserted: int
    updated: int
    unchanged: int
    failed: int


class EmbeddingPersistenceService:
    """
    Persists generated chunk embeddings into PostgreSQL.

    Responsibilities:
    - Validate chunk ownership and content hashes.
    - Validate embedding metadata and dimensions.
    - Insert or update embedding records.
    - Track failed embedding outcomes.
    - Provide transaction-safe persistence.
    """

    def __init__(
        self,
        settings: EmbeddingSettings | None = None,
    ) -> None:
        self.settings = settings or EmbeddingSettings.from_env()

    def _validate_outcome(
        self,
        outcome: ChunkEmbeddingOutcome,
    ) -> None:
        if not outcome.chunk_id:
            raise EmbeddingPersistenceValidationError(
                "Chunk ID cannot be empty."
            )

        if not outcome.content_hash:
            raise EmbeddingPersistenceValidationError(
                "Content hash cannot be empty."
            )

        if outcome.status not in {"ready", "failed"}:
            raise EmbeddingPersistenceValidationError(
                f"Unsupported embedding status: {outcome.status}"
            )

        if outcome.status == "ready":
            if outcome.embedding is None:
                raise EmbeddingPersistenceValidationError(
                    "Ready embedding outcome must contain an embedding."
                )

            if outcome.embedding.dimensions != DATABASE_VECTOR_DIMENSIONS:
                raise EmbeddingPersistenceValidationError(
                    "Embedding dimensions do not match database "
                    f"VECTOR({DATABASE_VECTOR_DIMENSIONS})."
                )

            if len(outcome.embedding.vector) != DATABASE_VECTOR_DIMENSIONS:
                raise EmbeddingPersistenceValidationError(
                    "Embedding vector length does not match "
                    "database dimensions."
                )

            if outcome.embedding.provider != self.settings.provider:
                raise EmbeddingPersistenceValidationError(
                    "Embedding provider does not match configuration."
                )

            if outcome.embedding.model != self.settings.model:
                raise EmbeddingPersistenceValidationError(
                    "Embedding model does not match configuration."
                )

    @staticmethod
    def _get_chunk(
        db: Session,
        chunk_id: str,
    ) -> DocumentChunk | None:
        statement = select(DocumentChunk).where(
            DocumentChunk.chunk_id == chunk_id
        )

        return db.execute(statement).scalars().first()

    @staticmethod
    def _get_existing_embedding(
        db: Session,
        outcome: ChunkEmbeddingOutcome,
    ) -> ChunkEmbedding | None:
        statement = select(ChunkEmbedding).where(
            ChunkEmbedding.chunk_id == outcome.chunk_id,
            ChunkEmbedding.content_hash == outcome.content_hash,
            ChunkEmbedding.provider == (
                outcome.embedding.provider
                if outcome.embedding
                else None
            ),
            ChunkEmbedding.model == (
                outcome.embedding.model
                if outcome.embedding
                else None
            ),
            ChunkEmbedding.pipeline_version == PIPELINE_VERSION,
        )

        # Failed outcomes may not contain provider/model metadata.
        # Their records are located by chunk and content hash.
        if outcome.embedding is None:
            statement = select(ChunkEmbedding).where(
                ChunkEmbedding.chunk_id == outcome.chunk_id,
                ChunkEmbedding.content_hash == outcome.content_hash,
                ChunkEmbedding.pipeline_version == PIPELINE_VERSION,
            )

        return db.execute(statement).scalars().first()

    def _build_embedding_values(
        self,
        outcome: ChunkEmbeddingOutcome,
    ) -> dict:
        if outcome.status == "failed":
            return {
                "status": "failed",
                "embedding": None,
                "error_code": outcome.error_code or "UNKNOWN_ERROR",
                "dimensions": DATABASE_VECTOR_DIMENSIONS,
            }

        result = outcome.embedding

        return {
            "status": "ready",
            "embedding": list(result.vector),
            "provider": result.provider,
            "model": result.model,
            "model_version": result.model,
            "dimensions": result.dimensions,
            "error_code": None,
        }

    def persist(
        self,
        db: Session,
        outcomes: Sequence[ChunkEmbeddingOutcome],
    ) -> EmbeddingPersistenceResult:
        """
        Persist a sequence of embedding outcomes in one transaction.

        The method commits only after all outcomes have been processed.
        If any database operation fails, the transaction is rolled back.
        """

        if isinstance(outcomes, (str, bytes)):
            raise EmbeddingPersistenceValidationError(
                "Outcomes must be a sequence of embedding outcomes."
            )

        counters = {
            "inserted": 0,
            "updated": 0,
            "unchanged": 0,
            "failed": 0,
        }

        try:
            for outcome in outcomes:
                self._validate_outcome(outcome)

                chunk = self._get_chunk(db, outcome.chunk_id)

                if chunk is None:
                    raise EmbeddingPersistenceValidationError(
                        f"Document chunk not found: {outcome.chunk_id}"
                    )

                if chunk.content_hash != outcome.content_hash:
                    raise EmbeddingPersistenceValidationError(
                        "Chunk content hash mismatch. "
                        "The chunk may have changed since embedding."
                    )

                existing = self._get_existing_embedding(
                    db,
                    outcome,
                )

                values = self._build_embedding_values(outcome)

                if existing is not None:
                    is_unchanged = (
                        existing.status == values["status"]
                        and existing.embedding == values["embedding"]
                        and existing.error_code == values["error_code"]
                    )

                    if is_unchanged:
                        counters["unchanged"] += 1
                        continue

                    for field, value in values.items():
                        setattr(existing, field, value)

                    counters["updated"] += 1

                else:
                    metadata = {
                        "chunk_id": outcome.chunk_id,
                        "content_hash": outcome.content_hash,
                        "pipeline_version": PIPELINE_VERSION,
                        **values,
                    }

                    if outcome.embedding is not None:
                        metadata["provider"] = outcome.embedding.provider
                        metadata["model"] = outcome.embedding.model
                        metadata["model_version"] = (
                            outcome.embedding.model
                        )
                    else:
                        metadata["provider"] = self.settings.provider
                        metadata["model"] = self.settings.model
                        metadata["model_version"] = self.settings.model

                    db.add(ChunkEmbedding(**metadata))
                    counters["inserted"] += 1

                if outcome.status == "failed":
                    counters["failed"] += 1

            db.flush()
            db.commit()

        except Exception:
            db.rollback()
            raise

        return EmbeddingPersistenceResult(
            total=len(outcomes),
            inserted=counters["inserted"],
            updated=counters["updated"],
            unchanged=counters["unchanged"],
            failed=counters["failed"],
        )