from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from app.services.embeddings.embedding_persistence import (
    EmbeddingPersistenceService,
    EmbeddingPersistenceValidationError,
)
from app.services.embeddings.embedding_pipeline import (
    ChunkEmbeddingOutcome,
)
from app.schemas.embeddings import EmbeddingResult


DIMENSIONS = 1536

SETTINGS = SimpleNamespace(
    provider="gemini",
    model="gemini-embedding-2",
)


def make_embedding():
    return EmbeddingResult(
        vector=tuple([0.1] * DIMENSIONS),
        model="gemini-embedding-2",
        provider="gemini",
        dimensions=DIMENSIONS,
    )


def make_outcome(
    status="ready",
    embedding=None,
):
    return ChunkEmbeddingOutcome(
        chunk_id="chunk-001",
        content_hash="test-content-hash",
        status=status,
        embedding=embedding if embedding is not None else (
            make_embedding() if status == "ready" else None
        ),
        error_code="PROVIDER_ERROR" if status == "failed" else None,
    )


def make_db(existing=None):
    db = MagicMock()
    db.execute.return_value.scalars.return_value.first.return_value = existing
    return db


def make_chunk():
    return SimpleNamespace(
        chunk_id="chunk-001",
        content_hash="test-content-hash",
    )


def make_service():
    service = EmbeddingPersistenceService.__new__(
        EmbeddingPersistenceService
    )
    service.settings = SETTINGS
    return service


def configure_database(db, existing=None):
    # First SELECT returns the document chunk.
    # Second SELECT returns an existing embedding, if present.
    db.execute.side_effect = [
        MagicMock(
            scalars=MagicMock(
                return_value=MagicMock(
                    first=MagicMock(return_value=make_chunk())
                )
            )
        ),
        MagicMock(
            scalars=MagicMock(
                return_value=MagicMock(
                    first=MagicMock(return_value=existing)
                )
            )
        ),
    ]


def test_persists_new_embedding():
    db = make_db()
    configure_database(db)

    result = make_service().persist(
        db,
        [make_outcome()],
    )

    assert result.total == 1
    assert result.inserted == 1
    assert result.updated == 0
    db.add.assert_called_once()
    db.commit.assert_called_once()


def test_persists_failed_outcome():
    db = make_db()
    configure_database(db)

    result = make_service().persist(
        db,
        [make_outcome(status="failed")],
    )

    assert result.failed == 1
    assert result.inserted == 1
    db.add.assert_called_once()


def test_rejects_wrong_dimensions():
    db = make_db()

    invalid_embedding = EmbeddingResult(
        vector=tuple([0.1] * 768),
        model="gemini-embedding-2",
        provider="gemini",
        dimensions=768,
    )

    outcome = make_outcome(embedding=invalid_embedding)

    with pytest.raises(EmbeddingPersistenceValidationError):
        make_service().persist(db, [outcome])

    db.commit.assert_not_called()


def test_rejects_missing_chunk():
    db = make_db()
    db.execute.return_value.scalars.return_value.first.return_value = None

    with pytest.raises(EmbeddingPersistenceValidationError):
        make_service().persist(db, [make_outcome()])

    db.rollback.assert_called_once()


def test_rejects_content_hash_mismatch():
    db = make_db()

    wrong_chunk = SimpleNamespace(
        chunk_id="chunk-001",
        content_hash="different-hash",
    )

    db.execute.return_value.scalars.return_value.first.return_value = (
        wrong_chunk
    )

    with pytest.raises(EmbeddingPersistenceValidationError):
        make_service().persist(db, [make_outcome()])

    db.rollback.assert_called_once()


def test_rolls_back_database_failure():
    db = make_db()
    configure_database(db)
    db.flush.side_effect = RuntimeError("Database failure")

    with pytest.raises(RuntimeError):
        make_service().persist(db, [make_outcome()])

    db.rollback.assert_called_once()
    db.commit.assert_not_called()


def test_rejects_invalid_status():
    db = make_db()

    outcome = ChunkEmbeddingOutcome(
        chunk_id="chunk-001",
        content_hash="test-content-hash",
        status="pending",
    )

    with pytest.raises(EmbeddingPersistenceValidationError):
        make_service().persist(db, [outcome])

    db.commit.assert_not_called()